import React, { useState, useEffect } from 'react';
import { dbService } from '../services/db';
import { Order, Customer } from '../types';
import { ArrowLeft, LogOut, ShoppingBag, Clock, CheckCircle, X, ChefHat, Loader2 } from 'lucide-react';

interface CustomerMyOrdersProps {
  customer: Customer;
  onBack: () => void;
  onLogout: () => void;
}

export const CustomerMyOrders: React.FC<CustomerMyOrdersProps> = ({ customer, onBack, onLogout }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOrders();
    
    const unsubscribe = dbService.subscribe((event) => {
      if (event.type === 'STATUS_UPDATE' || event.type === 'GENERIC_UPDATE') {
        loadOrders();
      }
    });
    
    return unsubscribe;
  }, [customer.id]);

  const loadOrders = async () => {
    const customerOrders = await dbService.getCustomerOrders(customer.id);
    setOrders(customerOrders.sort((a, b) => b.timestamp - a.timestamp));
    setLoading(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock size={18} className="text-gray-500" />;
      case 'preparing':
        return <ChefHat size={18} className="text-amber-600" />;
      case 'ready':
        return <CheckCircle size={18} className="text-green-600" />;
      case 'completed':
        return <ShoppingBag size={18} className="text-gray-400" />;
      case 'cancelled':
        return <X size={18} className="text-red-500" />;
      default:
        return <Clock size={18} className="text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-gray-100 text-gray-700';
      case 'preparing':
        return 'bg-amber-100 text-amber-700';
      case 'ready':
        return 'bg-green-100 text-green-700';
      case 'completed':
        return 'bg-gray-100 text-gray-500';
      case 'cancelled':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString(undefined, { 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white px-6 py-4 shadow-sm flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 -ml-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-xl font-bold text-gray-800">My Orders</h1>
            <p className="text-xs text-gray-500">{customer.name}</p>
          </div>
        </div>
        <button 
          onClick={onLogout}
          className="p-3 text-gray-600 hover:text-red-500 hover:bg-red-50 rounded-xl transition"
          title="Logout"
        >
          <LogOut size={22} />
        </button>
      </header>

      <main className="p-6 max-w-2xl mx-auto">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 size={48} className="text-amber-600 animate-spin mb-4" />
            <p className="text-gray-500">Loading your orders...</p>
          </div>
        ) : orders.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20">
            <ShoppingBag size={64} className="text-gray-300 mb-4" />
            <h2 className="text-xl font-bold text-gray-700 mb-2">No orders yet</h2>
            <p className="text-gray-500 mb-6">Your order history will appear here.</p>
            <button 
              onClick={onBack}
              className="px-6 py-3 bg-amber-600 text-white rounded-xl font-bold hover:bg-amber-700 transition"
            >
              Start Ordering
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map(order => (
              <div key={order.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                <div className="p-4 border-b border-gray-50 flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Order #{order.id.toString().slice(-4)}</p>
                    <p className="text-xs text-gray-400">{formatDate(order.timestamp)}</p>
                  </div>
                  <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium ${getStatusColor(order.status)}`}>
                    {getStatusIcon(order.status)}
                    <span className="capitalize">{order.status}</span>
                  </div>
                </div>
                
                <div className="p-4">
                  <div className="space-y-2 mb-4">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between text-sm">
                        <span className="text-gray-700">
                          {item.quantity}x {item.name}
                          {item.instructions && (
                            <span className="text-gray-400 text-xs ml-2">({item.instructions})</span>
                          )}
                        </span>
                        <span className="text-gray-600">{(item.price * item.quantity).toLocaleString()} MMK</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex justify-between items-center pt-3 border-t border-gray-100">
                    <span className="text-gray-500 text-sm">Table {order.tableNumber}</span>
                    <span className="font-bold text-amber-600">{order.total.toLocaleString()} MMK</span>
                  </div>
                </div>

                {(order.status === 'preparing' || order.status === 'ready') && (
                  <div className={`px-4 py-3 ${order.status === 'ready' ? 'bg-green-50' : 'bg-amber-50'}`}>
                    <p className={`text-sm font-medium text-center ${order.status === 'ready' ? 'text-green-700' : 'text-amber-700'}`}>
                      {order.status === 'ready' 
                        ? 'Your order is ready! Please pick up at the counter.' 
                        : 'Your order is being prepared...'}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};
