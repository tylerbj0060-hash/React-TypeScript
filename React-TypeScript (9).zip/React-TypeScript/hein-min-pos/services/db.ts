import { MenuItem, Order, Customer } from '../types';

const API_BASE = '/api';

export type DBEventType = 'NEW_ORDER' | 'STATUS_UPDATE' | 'MENU_UPDATE' | 'GENERIC_UPDATE';

export interface DBEvent {
  type: DBEventType;
  data?: any;
}

class DBService {
  private listeners: ((event: DBEvent) => void)[] = [];
  private pollInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.startPolling();
  }

  private startPolling() {
    this.pollInterval = setInterval(() => {
      this.notifyListeners({ type: 'GENERIC_UPDATE' });
    }, 5000);
  }

  subscribe(listener: (event: DBEvent) => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notifyListeners(event: DBEvent) {
    this.listeners.forEach(l => l(event));
  }

  async init(): Promise<void> {
    console.log("Connected to PostgreSQL Database via API");
  }

  async getMenu(): Promise<MenuItem[]> {
    try {
      const response = await fetch(`${API_BASE}/menu`);
      if (!response.ok) throw new Error('Failed to fetch menu');
      return await response.json();
    } catch (error) {
      console.error('Error fetching menu:', error);
      return [];
    }
  }

  async addMenuItem(item: Omit<MenuItem, 'id'>): Promise<number> {
    try {
      const response = await fetch(`${API_BASE}/menu`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(item)
      });
      if (!response.ok) throw new Error('Failed to add menu item');
      const newItem = await response.json();
      this.notifyListeners({ type: 'MENU_UPDATE' });
      return newItem.id;
    } catch (error) {
      console.error('Error adding menu item:', error);
      throw error;
    }
  }

  async updateMenuItem(item: MenuItem): Promise<void> {
    try {
      const response = await fetch(`${API_BASE}/menu/${item.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(item)
      });
      if (!response.ok) throw new Error('Failed to update menu item');
      this.notifyListeners({ type: 'MENU_UPDATE' });
    } catch (error) {
      console.error('Error updating menu item:', error);
      throw error;
    }
  }

  async deleteMenuItem(id: number): Promise<void> {
    try {
      const response = await fetch(`${API_BASE}/menu/${id}`, {
        method: 'DELETE'
      });
      if (!response.ok) throw new Error('Failed to delete menu item');
      this.notifyListeners({ type: 'MENU_UPDATE' });
    } catch (error) {
      console.error('Error deleting menu item:', error);
      throw error;
    }
  }

  async saveOrder(order: Order): Promise<void> {
    try {
      const response = await fetch(`${API_BASE}/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(order)
      });
      if (!response.ok) throw new Error('Failed to save order');
      this.notifyListeners({ type: 'NEW_ORDER', data: order });
    } catch (error) {
      console.error('Error saving order:', error);
      throw error;
    }
  }

  async updateOrderStatus(orderId: number, status: Order['status']): Promise<void> {
    try {
      const response = await fetch(`${API_BASE}/orders/${orderId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (!response.ok) throw new Error('Failed to update order status');
      this.notifyListeners({ type: 'STATUS_UPDATE', data: { orderId, status } });
    } catch (error) {
      console.error('Error updating order status:', error);
      throw error;
    }
  }

  async getOrders(): Promise<Order[]> {
    try {
      const response = await fetch(`${API_BASE}/orders`);
      if (!response.ok) throw new Error('Failed to fetch orders');
      return await response.json();
    } catch (error) {
      console.error('Error fetching orders:', error);
      return [];
    }
  }

  async getOrdersByDate(date: Date): Promise<Order[]> {
    try {
      const dateStr = date.toISOString().split('T')[0];
      const response = await fetch(`${API_BASE}/orders/date/${dateStr}`);
      if (!response.ok) throw new Error('Failed to fetch orders by date');
      return await response.json();
    } catch (error) {
      console.error('Error fetching orders by date:', error);
      return [];
    }
  }

  async deleteOrder(id: number): Promise<void> {
    try {
      const response = await fetch(`${API_BASE}/orders/${id}`, {
        method: 'DELETE'
      });
      if (!response.ok) throw new Error('Failed to delete order');
      this.notifyListeners({ type: 'GENERIC_UPDATE' });
    } catch (error) {
      console.error('Error deleting order:', error);
      throw error;
    }
  }

  async clearOrdersByDate(date: Date): Promise<number> {
    try {
      const dateStr = date.toISOString().split('T')[0];
      const response = await fetch(`${API_BASE}/orders/date/${dateStr}`, {
        method: 'DELETE'
      });
      if (!response.ok) throw new Error('Failed to clear orders by date');
      const result = await response.json();
      this.notifyListeners({ type: 'GENERIC_UPDATE' });
      return result.deletedCount;
    } catch (error) {
      console.error('Error clearing orders by date:', error);
      return 0;
    }
  }

  async registerCustomer(name: string, phone: string, password: string): Promise<{ success: boolean; customer?: Customer; error?: string }> {
    try {
      const response = await fetch(`${API_BASE}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, phone, password })
      });
      const data = await response.json();
      if (!response.ok) {
        return { success: false, error: data.error || 'Registration failed' };
      }
      return { success: true, customer: data.customer };
    } catch (error) {
      console.error('Error registering customer:', error);
      return { success: false, error: 'Registration failed' };
    }
  }

  async loginCustomer(phone: string, password: string): Promise<{ success: boolean; customer?: Customer; error?: string }> {
    try {
      const response = await fetch(`${API_BASE}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, password })
      });
      const data = await response.json();
      if (!response.ok) {
        return { success: false, error: data.error || 'Login failed' };
      }
      return { success: true, customer: data.customer };
    } catch (error) {
      console.error('Error logging in:', error);
      return { success: false, error: 'Login failed' };
    }
  }

  async getCustomerOrders(customerId: number): Promise<Order[]> {
    try {
      const response = await fetch(`${API_BASE}/customer/${customerId}/orders`);
      if (!response.ok) throw new Error('Failed to fetch customer orders');
      return await response.json();
    } catch (error) {
      console.error('Error fetching customer orders:', error);
      return [];
    }
  }
}

export const dbService = new DBService();
