import express from 'express';
import cors from 'cors';
import pg from 'pg';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const { Pool } = pg;

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json({ limit: '10mb' }));

app.use(express.static(path.join(__dirname, '../dist')));

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

pool.connect()
  .then(() => console.log('Connected to PostgreSQL database'))
  .catch(err => console.error('Database connection error:', err));

function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, phone, password } = req.body;
    if (!name || !phone || !password) {
      return res.status(400).json({ error: 'Name, phone, and password are required' });
    }
    const existing = await pool.query('SELECT id FROM customers WHERE phone = $1', [phone]);
    if (existing.rows.length > 0) {
      return res.status(400).json({ error: 'Phone number already registered' });
    }
    const hashedPassword = hashPassword(password);
    const result = await pool.query(
      'INSERT INTO customers (name, phone, password) VALUES ($1, $2, $3) RETURNING id, name, phone, created_at',
      [name, phone, hashedPassword]
    );
    res.json({ success: true, customer: result.rows[0] });
  } catch (error) {
    console.error('Error registering customer:', error);
    res.status(500).json({ error: 'Failed to register' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { phone, password } = req.body;
    if (!phone || !password) {
      return res.status(400).json({ error: 'Phone and password are required' });
    }
    const hashedPassword = hashPassword(password);
    const result = await pool.query(
      'SELECT id, name, phone, created_at FROM customers WHERE phone = $1 AND password = $2',
      [phone, hashedPassword]
    );
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid phone or password' });
    }
    res.json({ success: true, customer: result.rows[0] });
  } catch (error) {
    console.error('Error logging in:', error);
    res.status(500).json({ error: 'Failed to login' });
  }
});

app.get('/api/customer/:id/orders', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      'SELECT * FROM orders WHERE customer_id = $1 ORDER BY timestamp DESC',
      [id]
    );
    res.json(result.rows.map(row => ({
      id: row.id,
      timestamp: parseInt(row.timestamp),
      tableNumber: row.table_number,
      customerName: row.customer_name,
      items: row.items,
      total: row.total,
      status: row.status,
      customerId: row.customer_id
    })));
  } catch (error) {
    console.error('Error fetching customer orders:', error);
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

app.get('/api/menu', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM menu_items ORDER BY id');
    res.json(result.rows.map(row => ({
      id: row.id,
      name: row.name,
      price: row.price,
      category: row.category,
      description: row.description,
      image: row.image
    })));
  } catch (error) {
    console.error('Error fetching menu:', error);
    res.status(500).json({ error: 'Failed to fetch menu' });
  }
});

app.post('/api/menu', async (req, res) => {
  try {
    const { name, price, category, description, image } = req.body;
    const result = await pool.query(
      'INSERT INTO menu_items (name, price, category, description, image) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [name, price, category, description || '', image || '']
    );
    res.json({
      id: result.rows[0].id,
      name: result.rows[0].name,
      price: result.rows[0].price,
      category: result.rows[0].category,
      description: result.rows[0].description,
      image: result.rows[0].image
    });
  } catch (error) {
    console.error('Error adding menu item:', error);
    res.status(500).json({ error: 'Failed to add menu item' });
  }
});

app.put('/api/menu/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, price, category, description, image } = req.body;
    const result = await pool.query(
      'UPDATE menu_items SET name = $1, price = $2, category = $3, description = $4, image = $5 WHERE id = $6 RETURNING *',
      [name, price, category, description || '', image || '', id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Menu item not found' });
    }
    res.json({
      id: result.rows[0].id,
      name: result.rows[0].name,
      price: result.rows[0].price,
      category: result.rows[0].category,
      description: result.rows[0].description,
      image: result.rows[0].image
    });
  } catch (error) {
    console.error('Error updating menu item:', error);
    res.status(500).json({ error: 'Failed to update menu item' });
  }
});

app.delete('/api/menu/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM menu_items WHERE id = $1', [id]);
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting menu item:', error);
    res.status(500).json({ error: 'Failed to delete menu item' });
  }
});

app.get('/api/orders', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM orders ORDER BY timestamp DESC');
    res.json(result.rows.map(row => ({
      id: row.id,
      timestamp: parseInt(row.timestamp),
      tableNumber: row.table_number,
      customerName: row.customer_name,
      items: row.items,
      total: row.total,
      status: row.status
    })));
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

app.get('/api/orders/date/:date', async (req, res) => {
  try {
    const { date } = req.params;
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const result = await pool.query(
      'SELECT * FROM orders WHERE timestamp >= $1 AND timestamp <= $2 ORDER BY timestamp DESC',
      [startOfDay.getTime(), endOfDay.getTime()]
    );
    res.json(result.rows.map(row => ({
      id: row.id,
      timestamp: parseInt(row.timestamp),
      tableNumber: row.table_number,
      customerName: row.customer_name,
      items: row.items,
      total: row.total,
      status: row.status
    })));
  } catch (error) {
    console.error('Error fetching orders by date:', error);
    res.status(500).json({ error: 'Failed to fetch orders by date' });
  }
});

app.post('/api/orders', async (req, res) => {
  try {
    const { timestamp, tableNumber, customerName, items, total, status, customerId } = req.body;
    const itemsJson = typeof items === 'string' ? items : JSON.stringify(items);
    const result = await pool.query(
      'INSERT INTO orders (timestamp, table_number, customer_name, items, total, status, customer_id) VALUES ($1, $2, $3, $4::jsonb, $5, $6, $7) RETURNING *',
      [timestamp, tableNumber, customerName, itemsJson, total, status || 'pending', customerId || null]
    );
    res.json({
      id: result.rows[0].id,
      timestamp: parseInt(result.rows[0].timestamp),
      tableNumber: result.rows[0].table_number,
      customerName: result.rows[0].customer_name,
      items: result.rows[0].items,
      total: result.rows[0].total,
      status: result.rows[0].status,
      customerId: result.rows[0].customer_id
    });
  } catch (error) {
    console.error('Error creating order:', error);
    res.status(500).json({ error: 'Failed to create order' });
  }
});

app.put('/api/orders/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const result = await pool.query(
      'UPDATE orders SET status = $1 WHERE id = $2 RETURNING *',
      [status, id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Order not found' });
    }
    res.json({
      id: result.rows[0].id,
      timestamp: parseInt(result.rows[0].timestamp),
      tableNumber: result.rows[0].table_number,
      customerName: result.rows[0].customer_name,
      items: result.rows[0].items,
      total: result.rows[0].total,
      status: result.rows[0].status
    });
  } catch (error) {
    console.error('Error updating order status:', error);
    res.status(500).json({ error: 'Failed to update order status' });
  }
});

app.delete('/api/orders/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM orders WHERE id = $1', [id]);
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting order:', error);
    res.status(500).json({ error: 'Failed to delete order' });
  }
});

app.delete('/api/orders/date/:date', async (req, res) => {
  try {
    const { date } = req.params;
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const result = await pool.query(
      'DELETE FROM orders WHERE timestamp >= $1 AND timestamp <= $2',
      [startOfDay.getTime(), endOfDay.getTime()]
    );
    res.json({ deletedCount: result.rowCount });
  } catch (error) {
    console.error('Error clearing orders by date:', error);
    res.status(500).json({ error: 'Failed to clear orders by date' });
  }
});

app.get('/{*splat}', (req, res) => {
  res.sendFile(path.join(__dirname, '../dist/index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`API Server running on http://0.0.0.0:${PORT}`);
});
