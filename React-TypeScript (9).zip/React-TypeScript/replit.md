# Hein Min POS System

## Overview

Hein Min POS is a modern Point of Sale system designed for a coffee shop. The application features a dual-interface design: a customer-facing kiosk for self-service ordering with real-time order tracking, and an admin dashboard for managing menu items, monitoring orders, and generating sales reports. The system uses PostgreSQL for data persistence and integrates Google's Gemini AI for intelligent sales analytics.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18+ with TypeScript, built using Vite for fast development and optimized production builds.

**UI Design Pattern**: The application uses a tab-based navigation system with distinct user flows:
- Landing page serves as entry point for role selection (admin vs customer)
- Admin flow: Dashboard → Menu Management → Reports
- Customer flow: Kiosk ordering → Order tracking → Success screen

**State Management**: Component-level state using React hooks (useState, useEffect). Real-time updates are handled through a polling-based subscription system in the database service layer.

**Styling**: TailwindCSS via CDN for utility-first styling, with custom print styles for receipt generation. The Inter font family provides a modern, professional appearance.

**Component Structure**:
- `AdminDashboard`: Real-time order monitoring with status updates and audio notifications
- `CustomerKiosk`: Self-service ordering interface with product variations, cart management, and order tracking
- `MenuManager`: CRUD operations for menu items with image upload support
- `Reports`: Sales analytics with date filtering and AI-generated insights
- `Voucher`: Printable receipt component
- `OrderSystem`: Alternative ordering interface (appears to be legacy/backup)

### Backend Architecture

**Server Framework**: Express.js (v5.2.1) with CORS enabled for cross-origin requests.

**API Design**: RESTful API with JSON payload handling (10MB limit to accommodate base64-encoded images).

**Database Layer**: PostgreSQL accessed through the `pg` library with connection pooling for efficient resource management.

**Database Service**: The `db.ts` service acts as an abstraction layer providing:
- Menu item CRUD operations
- Order creation and retrieval
- Date-based order filtering
- Real-time update notifications via polling (5-second intervals)
- Event subscription system for cross-component communication

**Data Models**:
- `MenuItem`: Product catalog with name, price, category, description, and base64 image
- `Order`: Transaction records with customer info, items, status tracking, and timestamps
- `CartItem`: Extended MenuItem with quantity and special instructions

**Order Status Flow**: Orders progress through states: pending → preparing → ready → completed/cancelled

### Data Storage

**Database**: PostgreSQL with the following schema:
- `menu_items` table: Stores product catalog with image data as base64 strings
- `orders` table: Stores order transactions with JSONB for flexible item storage
- Connection managed via environment variable `DATABASE_URL`

**Local Storage**: Used for:
- Persisting active order ID for customer kiosk session recovery
- Maintaining state across page refreshes

**Image Handling**: Product images are converted to base64 strings (4MB size limit) and stored directly in the database, simplifying deployment but potentially impacting performance at scale.

### External Dependencies

**Google Gemini AI Integration**:
- Purpose: Generates intelligent sales analytics and actionable business insights
- API: `@google/genai` SDK (v1.31.0)
- Model: gemini-2.5-flash
- Configuration: Requires `GEMINI_API_KEY` environment variable
- Usage: Analyzes daily sales data to provide performance summaries and recommendations

**Key Libraries**:
- `lucide-react` (v0.556.0): Icon library for consistent UI elements
- `react` & `react-dom` (v19.2.1): Core framework
- `pg` (v8.16.3): PostgreSQL client
- `cors` (v2.8.5): Cross-origin resource sharing
- `express` (v5.2.1): Web server framework

**Development Tools**:
- Vite (v6.2.0): Build tool and dev server
- TypeScript (v5.8.2): Type safety
- @vitejs/plugin-react: React integration for Vite

**API Endpoints**:
- `GET /api/menu`: Fetch all menu items
- `POST /api/menu`: Create new menu item
- `PUT /api/menu/:id`: Update menu item
- `DELETE /api/menu/:id`: Remove menu item
- `GET /api/orders`: Fetch all orders
- `POST /api/orders`: Create new order
- `PUT /api/orders/:id`: Update order status
- `GET /api/orders/date/:date`: Fetch orders by date
- `DELETE /api/orders/date/:date`: Clear orders for specific date

**Authentication**: Simple email-based admin access (hardcoded to `zanjo3717@gmail.com`). This is not production-ready and should be replaced with proper authentication.

**Real-time Features**: Polling-based updates every 5 seconds enable multi-device synchronization. New orders trigger audio notifications in the admin dashboard using Web Audio API.

**Print Functionality**: Browser-native print API with custom CSS media queries for receipt formatting.